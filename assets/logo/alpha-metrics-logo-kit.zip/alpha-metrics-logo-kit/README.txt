alpha-metrics.ai logo kit
=========================

Files
  alpha-metrics-logo         tile and wordmark, for light backgrounds
  alpha-metrics-logo-dark    tile and wordmark, for dark backgrounds
  alpha-metrics-mark         tile alone (profile pictures, app icons)
  alpha-metrics-mark-dark    tile alone, for dark backgrounds
  alpha-metrics              wordmark alone, dark blue
  alpha-metrics-dark         wordmark alone, light blue, for dark backgrounds
  alpha-metrics-white        wordmark alone, white
  alpha-metrics-ink          wordmark alone, one colour, for print
  alpha-metrics-tagline      wordmark with "Where science meets business"
  alpha-metrics-tagline-dark the same, for dark backgrounds

Use the SVG files wherever you can; they stay sharp at every size.
The PNG files have a transparent background; the number is the width in pixels.

Colours
  Dark blue   #104281   logo on light backgrounds
  Light blue  #9cc3f3   logo on dark backgrounds
  Ink         #0e1a2b   one-colour print
  Grey        #9b9a92   tagline on light backgrounds

Please keep clear space around the logo of at least the tile's width,
and do not stretch, recolour or rearrange it.

https://alpha-metrics.ai/logo.html
